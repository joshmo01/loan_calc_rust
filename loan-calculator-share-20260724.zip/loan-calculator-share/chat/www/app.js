import init, { calc_repayments, validate_params } from "./pkg/structured_loan_wasm.js";

const WASM_URL = new URL("./pkg/structured_loan_wasm_bg.wasm", import.meta.url);

let wasmReady = false;
let lastResult = null;
/** @type {{role: string, content: string}[]} */
let history = [];

const QUICK = [
  "I want a 20 lakh home loan for 20 years at 8.5% monthly EMI",
  "5 crore term loan, 36 months, 11% quarterly, 50k processing fee",
  "1 crore, 5 years, 12%, 6 month moratorium then EMI",
  "50 lakh balloon loan: 48 months EMI then 12 balloon payments of 2 lakh",
  "Recalculate at 10.25% rate with same tenure",
];

function $(id) {
  return document.getElementById(id);
}

function fmt(n) {
  if (n === null || n === undefined) return "—";
  const x = Number(n);
  if (Number.isNaN(x)) return String(n);
  return x.toLocaleString(undefined, {
    minimumFractionDigits: 2,
    maximumFractionDigits: 2,
  });
}

function fmtPct(n) {
  if (n === null || n === undefined) return "—";
  return `${fmt(n)}%`;
}

function showError(msg) {
  const box = $("error");
  if (!msg) {
    box.classList.remove("visible");
    box.textContent = "";
    return;
  }
  box.textContent = msg;
  box.classList.add("visible");
}

function addMsg(role, text, meta = "") {
  const log = $("chat-log");
  const div = document.createElement("div");
  div.className = `msg ${role}`;
  if (meta) {
    const m = document.createElement("span");
    m.className = "meta";
    m.textContent = meta;
    div.appendChild(m);
  }
  div.appendChild(document.createTextNode(text));
  log.appendChild(div);
  log.scrollTop = log.scrollHeight;
}

function setField(id, value) {
  const el = $(id);
  if (!el || value === null || value === undefined || value === "") return;
  el.value = value;
}

function monthsPerPeriod(frequency) {
  return { monthly: 1, quarterly: 3, "half-yearly": 6, yearly: 12 }[frequency] || 1;
}

function installmentCount(termMonths, frequency) {
  const m = monthsPerPeriod(frequency);
  return Math.floor(Number(termMonths) / m);
}

/** Build repay_structure phases from structure selector + optional fields. */
function buildPhases() {
  const structure = $("structure").value;
  const term = Number($("term_months").value);
  const freq = $("frequency").value;
  const n = installmentCount(term, freq);
  if (n <= 0) return [{ kind: "step", periods: 1, growth_rate_pct: 0, fixed_payment: 0 }];

  if (structure === "interest_only") {
    return [{ kind: "interest_only", periods: n, growth_rate_pct: 0, fixed_payment: 0 }];
  }
  if (structure === "moratorium_emi") {
    let m = Number($("moratorium_periods").value) || 0;
    m = Math.min(Math.max(m, 0), n - 1);
    const rest = n - m;
    const phases = [];
    if (m > 0) {
      phases.push({
        kind: "moratorium_capitalize",
        periods: m,
        growth_rate_pct: 0,
        fixed_payment: 0,
      });
    }
    phases.push({ kind: "step", periods: rest, growth_rate_pct: 0, fixed_payment: 0 });
    return phases;
  }
  if (structure === "balloon") {
    let b = Number($("balloon_periods").value) || 0;
    b = Math.min(Math.max(b, 1), n);
    const stepN = n - b;
    const fixed = Number($("balloon_payment").value) || 0;
    const phases = [];
    if (stepN > 0) {
      phases.push({ kind: "step", periods: stepN, growth_rate_pct: 0, fixed_payment: 0 });
    }
    phases.push({
      kind: "balloon",
      periods: b,
      growth_rate_pct: 0,
      fixed_payment: fixed,
    });
    return phases;
  }
  if (structure === "step_up") {
    const g = Number($("step_growth_pct").value) || 10;
    const third = Math.floor(n / 3);
    const rem = n - third * 2;
    if (third < 1) {
      return [{ kind: "step", periods: n, growth_rate_pct: 0, fixed_payment: 0 }];
    }
    return [
      { kind: "step", periods: third, growth_rate_pct: 0, fixed_payment: 0 },
      { kind: "step", periods: third, growth_rate_pct: g, fixed_payment: 0 },
      { kind: "step", periods: rem, growth_rate_pct: g, fixed_payment: 0 },
    ];
  }
  // emi
  return [{ kind: "step", periods: n, growth_rate_pct: 0, fixed_payment: 0 }];
}

function buildPayload() {
  return {
    principal: Number($("principal").value),
    rate: String($("rate").value),
    term_months: Number($("term_months").value),
    frequency: $("frequency").value,
    start_date: $("start_date").value,
    first_payment_date: $("first_payment_date").value,
    day_count: $("day_count").value,
    amortization: "straight_line",
    fees: Number($("fees").value) || 0,
    commission: Number($("commission").value) || 0,
    subvention: Number($("subvention").value) || 0,
    phases: buildPhases(),
  };
}

function applyExtractedParams(params) {
  if (!params || typeof params !== "object") return;

  if (params.principal != null) setField("principal", params.principal);
  if (params.annual_rate_pct != null) setField("rate", params.annual_rate_pct);
  // also accept "rate"
  if (params.rate != null && params.annual_rate_pct == null) setField("rate", params.rate);
  if (params.term_months != null) setField("term_months", params.term_months);
  if (params.frequency) setField("frequency", params.frequency);
  if (params.day_count) setField("day_count", params.day_count);
  if (params.start_date) setField("start_date", params.start_date);
  if (params.first_payment_date) setField("first_payment_date", params.first_payment_date);
  if (params.fees != null) setField("fees", params.fees);
  if (params.commission != null) setField("commission", params.commission);
  if (params.subvention != null) setField("subvention", params.subvention);
  if (params.moratorium_periods != null)
    setField("moratorium_periods", params.moratorium_periods);
  if (params.balloon_periods != null) setField("balloon_periods", params.balloon_periods);
  if (params.balloon_payment != null) setField("balloon_payment", params.balloon_payment);
  if (params.step_growth_pct != null) setField("step_growth_pct", params.step_growth_pct);
  if (params.structure) setField("structure", params.structure);
}

function renderResult(result) {
  lastResult = result;
  const s = result.summary;
  const r = result.returns;
  $("kpis").innerHTML = [
    ["EMI / payment", s.periodic_payment != null ? fmt(s.periodic_payment) : "Variable", "accent"],
    ["Total payment", fmt(s.total_payment), ""],
    ["Total interest", fmt(s.total_interest), ""],
    ["Net disbursement", fmt(s.net_disbursement), ""],
    ["IRR", fmtPct(r.irr), "good"],
    ["XIRR", fmtPct(r.xirr), "good"],
    ["NDIRR", fmtPct(r.ndirr), "good"],
    ["NDXIRR", fmtPct(r.ndxirr), "good"],
  ]
    .map(
      ([label, value, cls]) =>
        `<div class="kpi"><div class="label">${label}</div><div class="value ${cls}">${value}</div></div>`
    )
    .join("");

  const body = document.querySelector("#schedule-table tbody");
  body.innerHTML = result.schedule
    .map(
      (row) => `<tr>
      <td>${row.period}</td>
      <td>${row.date}</td>
      <td>${fmt(row.opening_balance)}</td>
      <td>${fmt(row.interest)}</td>
      <td>${fmt(row.principal)}</td>
      <td>${fmt(row.payment)}</td>
      <td>${fmt(row.closing_balance)}</td>
      <td>${row.phase}</td>
    </tr>`
    )
    .join("");
}

function runCalc() {
  if (!wasmReady) {
    showError("WASM not ready yet");
    return false;
  }
  showError("");
  const payload = buildPayload();
  const json = JSON.stringify(payload);
  const validation = JSON.parse(validate_params(json));
  if (!validation.ok) {
    showError(validation.errors.join(" · "));
    $("status").textContent = "Validation failed";
    return false;
  }
  const raw = calc_repayments(json);
  const result = JSON.parse(raw);
  if (result.error) {
    showError(result.error);
    $("status").textContent = "Error";
    return false;
  }
  renderResult(result);
  $("status").textContent = `WASM calculated · ${result.schedule.length} installments · ${result.meta.day_count}`;
  return true;
}

async function sendChat(userText) {
  const text = (userText || "").trim();
  if (!text) return;

  $("send-btn").disabled = true;
  addMsg("user", text);
  history.push({ role: "user", content: text });
  $("chat-input").value = "";

  const thinking = document.createElement("div");
  thinking.className = "msg bot";
  thinking.id = "thinking";
  thinking.textContent = "Thinking…";
  $("chat-log").appendChild(thinking);
  $("chat-log").scrollTop = $("chat-log").scrollHeight;

  try {
    const resp = await fetch("/api/chat", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ messages: history }),
    });
    const data = await resp.json();
    thinking.remove();

    if (!resp.ok || data.error) {
      const err = data.error || `HTTP ${resp.status}`;
      addMsg("bot", `Sorry — LLM error: ${err}`, "error");
      showError(err);
      return;
    }

    const reply = data.reply || "(no reply)";
    addMsg("bot", reply, data.model ? `model: ${data.model}` : "");
    // Store assistant content for multi-turn (plain reply is enough for history)
    history.push({ role: "assistant", content: reply });

    if (data.params) {
      applyExtractedParams(data.params);
      $("extract-debug").hidden = false;
      $("extract-debug").textContent =
        "Extracted: " + JSON.stringify(data.params, null, 0);
    }

    if (data.ready_to_calculate) {
      const ok = runCalc();
      if (ok && lastResult) {
        const s = lastResult.summary;
        addMsg(
          "system",
          `WASM engine ran · EMI/payment ${
            s.periodic_payment != null ? fmt(s.periodic_payment) : "variable"
          } · total interest ${fmt(s.total_interest)} · IRR ${fmtPct(
            lastResult.returns.irr
          )}`
        );
      }
    } else if (data.missing_fields && data.missing_fields.length) {
      $("status").textContent = "Missing: " + data.missing_fields.join(", ");
    }
  } catch (e) {
    thinking.remove();
    addMsg("bot", `Network error: ${e.message || e}`);
    showError(String(e.message || e));
  } finally {
    $("send-btn").disabled = false;
    $("chat-input").focus();
  }
}

function exportCsv() {
  if (!lastResult) return;
  const headers = [
    "period",
    "date",
    "opening_balance",
    "interest",
    "principal",
    "payment",
    "closing_balance",
    "phase",
  ];
  const lines = [headers.join(",")];
  for (const row of lastResult.schedule) {
    lines.push(headers.map((h) => row[h]).join(","));
  }
  const blob = new Blob([lines.join("\n")], { type: "text/csv" });
  const a = document.createElement("a");
  a.href = URL.createObjectURL(blob);
  a.download = "loan_schedule.csv";
  a.click();
  URL.revokeObjectURL(a.href);
}

async function checkHealth() {
  const badge = $("badge-llm");
  try {
    const r = await fetch("/api/health");
    const j = await r.json();
    if (j.ok) {
      badge.textContent = `LLM · ${j.model}`;
      badge.classList.add("ok");
      badge.title = j.base_url;
    } else {
      badge.textContent = "LLM offline";
      badge.classList.add("warn");
    }
  } catch {
    badge.textContent = "LLM unreachable";
    badge.classList.add("warn");
  }
}

async function main() {
  for (const q of QUICK) {
    const b = document.createElement("button");
    b.type = "button";
    b.className = "secondary";
    b.textContent = q.length > 48 ? q.slice(0, 48) + "…" : q;
    b.title = q;
    b.onclick = () => sendChat(q);
    $("quick-prompts").appendChild(b);
  }

  $("send-btn").onclick = () => sendChat($("chat-input").value);
  $("chat-input").addEventListener("keydown", (e) => {
    if (e.key === "Enter" && !e.shiftKey) {
      e.preventDefault();
      sendChat($("chat-input").value);
    }
  });
  $("calc-btn").onclick = () => runCalc();
  $("export-csv").onclick = exportCsv;

  addMsg(
    "system",
    "Describe your loan in plain language. I’ll extract parameters; the Rust WASM engine computes the schedule & IRR."
  );

  checkHealth();

  try {
    $("status").textContent = "Loading WASM…";
    await init({ module_or_path: WASM_URL });
    wasmReady = true;
    $("badge-wasm").textContent = "WASM ready";
    $("badge-wasm").classList.add("ok");
    $("status").textContent = "WASM ready — chat or edit params, then calculate";
    runCalc();
  } catch (e) {
    $("badge-wasm").textContent = "WASM failed";
    $("badge-wasm").classList.add("warn");
    $("status").textContent = "WASM failed";
    showError(String(e.message || e));
  }
}

main();
